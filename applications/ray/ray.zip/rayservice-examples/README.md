# Serve meta llama2 7b, llama2 70b quantized, falcon 7b-instruct or falcon 40b-instruct quantized models

The examples have moved to [kubernetes-engine-samples](https://github.com/GoogleCloudPlatform/kubernetes-engine-samples/tree/main/ai-ml/gke-ray/rayserve)

The documentation associated with the examples can be found on [Google Cloud Documentation](https://cloud.google.com/kubernetes-engine/docs/how-to/serve-llm-l4-ray)